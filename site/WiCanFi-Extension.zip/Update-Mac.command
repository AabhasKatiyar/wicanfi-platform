#!/bin/bash
# ================================================================
# WiCanFi - Apple Mac 1-Click Auto-Updater (macOS)
# ================================================================

# Switch to the directory where this script resides
cd "$(dirname "$0")" || exit 1

echo "================================================================"
echo "          WiCanFi Apple Mac 1-Click Auto-Updater (macOS)        "
echo "================================================================"
echo ""

# ─── Step 0: Auto-repair nested extraction ──────────────────────
if [ ! -f "manifest.json" ] && [ -d "WiCanFi-Extension" ] && [ -f "WiCanFi-Extension/manifest.json" ]; then
    echo "[Info] Flattening nested WiCanFi-Extension folder..."
    cp -R "WiCanFi-Extension/"* .
    rm -rf "WiCanFi-Extension"
fi

# ─── Step 1: Internet Connectivity Verification ─────────────────
echo "[1/3] Verifying internet connectivity..."

IS_ONLINE=0
if command -v curl &>/dev/null; then
    if curl -s --head --connect-timeout 4 http://clients3.google.com/generate_204 >/dev/null 2>&1 || \
       curl -s --head --connect-timeout 4 https://www.google.com >/dev/null 2>&1; then
        IS_ONLINE=1
    fi
elif command -v wget &>/dev/null; then
    if wget -q --spider --timeout=4 http://clients3.google.com/generate_204 >/dev/null 2>&1 || \
       wget -q --spider --timeout=4 https://www.google.com >/dev/null 2>&1; then
        IS_ONLINE=1
    fi
fi

if [ $IS_ONLINE -ne 1 ]; then
    echo ""
    echo "[ERROR] No internet connection detected."
    echo "Please connect to your campus Wi-Fi or mobile hotspot and try again."
    echo ""
    read -p "Press Enter to exit..."
    exit 1
fi

echo "[OK] Internet connection confirmed (Online)."
echo ""

# ─── Step 2: Fetch and Apply Updates ────────────────────────────
echo "[2/3] Checking for latest WiCanFi updates..."
UPDATED=0

# Path A: Current directory has .git
if [ -d ".git" ] && command -v git &>/dev/null; then
    echo "[Info] Git repository detected in current directory. Pulling latest commits..."
    if git pull origin main; then
        UPDATED=1
    fi
fi

# Path B: Parent directory has .git
if [ $UPDATED -ne 1 ] && [ -d "../.git" ] && command -v git &>/dev/null; then
    echo "[Info] Git repository detected in parent directory. Pulling..."
    if (cd .. && git pull origin main); then
        UPDATED=1
    fi
fi

# Path C: Git is installed on this machine (clone shallow to temp folder)
if [ $UPDATED -ne 1 ] && command -v git &>/dev/null; then
    echo "[Info] Fetching latest updates from GitHub showcase repository..."
    TEMP_GIT_DIR="/tmp/wicanfi_git_update_$$"
    rm -rf "$TEMP_GIT_DIR" 2>/dev/null
    
    if git clone --depth 1 https://github.com/AabhasKatiyar/wicanfi-platform.git "$TEMP_GIT_DIR" >/dev/null 2>&1; then
        echo "[Info] Applying updated extension files..."
        if [ -d "$TEMP_GIT_DIR/dist/WiCanFi-Extension" ]; then
            cp -R "$TEMP_GIT_DIR/dist/WiCanFi-Extension/"* .
        elif [ -d "$TEMP_GIT_DIR/extension" ]; then
            cp -R "$TEMP_GIT_DIR/extension/"* .
            cp "$TEMP_GIT_DIR/Update-Windows.bat" . 2>/dev/null || true
            cp "$TEMP_GIT_DIR/version.json" . 2>/dev/null || true
            cp "$TEMP_GIT_DIR/How-To-Install.txt" . 2>/dev/null || true
        fi
        rm -rf "$TEMP_GIT_DIR"
        UPDATED=1
    else
        rm -rf "$TEMP_GIT_DIR" 2>/dev/null
    fi
fi

# Path D: Local WiCanFi Server (Port 2134)
if [ $UPDATED -ne 1 ]; then
    TEMP_ZIP="wicanfi_update_$$.zip"
    TEMP_DIR="wicanfi_temp_$$"
    
    if curl -fsSL -m 3 -o "$TEMP_ZIP" "http://localhost:2134/api/download/extension" 2>/dev/null || curl -fsSL -m 3 -o "$TEMP_ZIP" "http://localhost:2025/api/download/extension" 2>/dev/null; then
        echo "[Info] Downloaded update package from local server..."
        mkdir -p "$TEMP_DIR"
        if unzip -q -o "$TEMP_ZIP" -d "$TEMP_DIR"; then
            if [ -f "$TEMP_DIR/manifest.json" ]; then
                cp -R "$TEMP_DIR/"* .
            elif [ -d "$TEMP_DIR/WiCanFi-Extension" ]; then
                cp -R "$TEMP_DIR/WiCanFi-Extension/"* .
            else
                cp -R "$TEMP_DIR/"* .
            fi
            UPDATED=1
        fi
        rm -rf "$TEMP_DIR" "$TEMP_ZIP"
    fi
fi

# Path E: Remote GitHub Release / Archive Download
if [ $UPDATED -ne 1 ]; then
    TEMP_ZIP="wicanfi_update_$$.zip"
    TEMP_DIR="wicanfi_temp_$$"
    URLS=(
        "https://wicanfi.pages.dev/WiCanFi-Extension.zip"
        "https://github.com/AabhasKatiyar/wicanfi-platform/releases/latest/download/WiCanFi-Extension.zip"
        "https://github.com/AabhasKatiyar/wicanfi-platform/archive/refs/heads/main.zip"
    )
    for u in "${URLS[@]}"; do
        if curl -fsSL -o "$TEMP_ZIP" "$u" 2>/dev/null || (command -v wget &>/dev/null && wget -qO "$TEMP_ZIP" "$u" 2>/dev/null); then
            if [ -s "$TEMP_ZIP" ]; then
                mkdir -p "$TEMP_DIR"
                if unzip -q -o "$TEMP_ZIP" -d "$TEMP_DIR"; then
                    if [ -f "$TEMP_DIR/manifest.json" ]; then
                        cp -R "$TEMP_DIR/"* .
                    elif [ -d "$TEMP_DIR/WiCanFi-Extension" ]; then
                        cp -R "$TEMP_DIR/WiCanFi-Extension/"* .
                    elif [ -d "$TEMP_DIR/wicanfi-main/extension" ]; then
                        cp -R "$TEMP_DIR/wicanfi-main/extension/"* .
                        cp "$TEMP_DIR/wicanfi-main/Update-Windows.bat" . 2>/dev/null || true
                        cp "$TEMP_DIR/wicanfi-main/version.json" . 2>/dev/null || true
                        cp "$TEMP_DIR/wicanfi-main/How-To-Install.txt" . 2>/dev/null || true
                    else
                        cp -R "$TEMP_DIR/"* .
                    fi
                    UPDATED=1
                    rm -rf "$TEMP_DIR" "$TEMP_ZIP"
                    break
                fi
                rm -rf "$TEMP_DIR" "$TEMP_ZIP"
            fi
        fi
    done
fi

if [ $UPDATED -ne 1 ]; then
    echo ""
    echo "================================================================"
    echo "[NOTICE] WiCanFi could not fetch a new update package."
    echo ""
    echo "Your internet connection is active and working properly."
    echo "However, the remote repository is either private or does not yet"
    echo "have a public release package published."
    echo "================================================================"
    echo ""
    read -p "Press Enter to exit..."
    exit 1
fi

# Ensure executable permissions are preserved
chmod +x Update-Mac.command 2>/dev/null

echo ""
echo "[3/3] Finalizing update..."
echo ""
echo "================================================================"
echo "  WiCanFi is now up to date!"
echo ""
echo "  Extension folder:"
echo "  $(pwd)"
echo "================================================================"
echo ""

# Open update summary and changelog page in user's browser
UPDATE_URL="https://wicanfi.pages.dev/update-success"

echo "[Info] Opening update summary and changelog in your browser..."
open "$UPDATE_URL" 2>/dev/null || open -a "Google Chrome" "$UPDATE_URL" 2>/dev/null || open -a "Microsoft Edge" "$UPDATE_URL" 2>/dev/null || true

echo "Update complete. The release notes page has opened in your browser."
read -p "Press Enter to finish..."
