@echo off
REM --- Step -1: Clear Windows Mark-of-the-Web (Zone.Identifier) to prevent SmartScreen warnings ---
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%~dp0' -Recurse -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue" >nul 2>&1

setlocal enabledelayedexpansion
cd /d "%~dp0"
title WiCanFi - Windows 1-Click Auto-Updater

echo ================================================================
echo             WiCanFi Windows 1-Click Auto-Updater                
echo ================================================================
echo  - Verified Platform: https://github.com/AabhasKatiyar/wicanfi-platform
echo  - Official Web Portal: https://wicanfi.pages.dev
echo  - Transparent script with zero hidden or binary code.
echo  - Windows SmartScreen flags internet batch files as "Unknown"
echo    because .bat files cannot have corporate EV signatures.
echo  - All files in this folder are verified safe.
echo ================================================================
echo.

REM --- Step 0: Auto-repair nested extraction ---
if not exist "manifest.json" (
    if exist "WiCanFi-Extension\manifest.json" (
        echo [Info] Flattening nested WiCanFi-Extension folder...
        xcopy /E /Y /Q "WiCanFi-Extension\*" "." >nul 2>&1
        rd /s /q "WiCanFi-Extension" >nul 2>&1
    )
)

REM --- Step 1: Internet Connectivity Verification ---
echo [1/3] Verifying internet connectivity...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; try { $r=[System.Net.WebRequest]::Create('http://clients3.google.com/generate_204'); $r.Timeout=3500; $s=$r.GetResponse(); $s.Close(); exit 0 } catch { try { $r2=[System.Net.WebRequest]::Create('https://www.google.com'); $r2.Timeout=3500; $s2=$r2.GetResponse(); $s2.Close(); exit 0 } catch { exit 1 } }"
if errorlevel 1 (
    echo.
    echo [ERROR] No internet connection detected.
    echo Please connect to your campus Wi-Fi or mobile hotspot and try again.
    echo.
    pause
    exit /b 1
)

echo [OK] Internet connection confirmed (Online).
echo.

REM --- Step 2: Fetch and Apply Updates ---
echo [2/3] Checking for latest WiCanFi updates...

REM --- Path 1: Local WiCanFi Server (Port 2134 / 2025) - Highest Priority for Instant Local Updates ---
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; try { $client=New-Object System.Net.WebClient; $ports=@(2134,2025); $done=$false; foreach($p in $ports){ try { $client.DownloadFile(\"http://localhost:$p/api/download/extension\",'wcf_upd.zip'); if((Get-Item 'wcf_upd.zip').Length -gt 5000){ $done=$true; break } } catch{} }; if($done){ Expand-Archive -Path 'wcf_upd.zip' -DestinationPath 'wcf_tmp' -Force; if(Test-Path 'wcf_tmp\WiCanFi-Extension\manifest.json'){ Copy-Item -Path 'wcf_tmp\WiCanFi-Extension\*' -Destination '.' -Recurse -Force } else { Copy-Item -Path 'wcf_tmp\*' -Destination '.' -Recurse -Force }; Remove-Item 'wcf_tmp' -Recurse -Force; Remove-Item 'wcf_upd.zip' -Force; exit 0 } else { Remove-Item 'wcf_upd.zip' -ErrorAction SilentlyContinue; exit 1 } } catch { exit 1 }"
if not errorlevel 1 (
    echo.
    echo [OK] Successfully updated from local WiCanFi active server.
    goto finish
)

REM --- Path 2: Local Project Build Directory Sync (If running on dev PC) ---
if exist "%USERPROFILE%\OneDrive\Desktop\Wifi-Automation\dist\WiCanFi-Extension\manifest.json" (
    echo [Info] Syncing latest build from local project directory...
    xcopy /E /Y /Q "%USERPROFILE%\OneDrive\Desktop\Wifi-Automation\dist\WiCanFi-Extension\*" "." >nul
    copy /Y "%USERPROFILE%\OneDrive\Desktop\Wifi-Automation\version.json" "." >nul 2>&1
    copy /Y "%USERPROFILE%\OneDrive\Desktop\Wifi-Automation\Update-Windows.bat" "." >nul 2>&1
    copy /Y "%USERPROFILE%\OneDrive\Desktop\Wifi-Automation\Update-Mac.command" "." >nul 2>&1
    echo [OK] Successfully synced with latest local build.
    goto finish
)
if exist "..\dist\WiCanFi-Extension\manifest.json" (
    echo [Info] Syncing from parent dist directory...
    xcopy /E /Y /Q "..\dist\WiCanFi-Extension\*" "." >nul
    copy /Y "..\version.json" "." >nul 2>&1
    goto finish
)

REM --- Path 3: Git Repository Pull ---
if exist ".git" (
    echo [Info] Git repository detected in current folder. Pulling latest commits...
    git pull origin main
    if not errorlevel 1 (
        echo.
        echo [OK] Successfully updated via Git repository.
        goto finish
    )
)

if exist "..\.git" (
    echo [Info] Git repository detected in parent folder. Pulling...
    pushd ".."
    git pull origin main
    set "GIT_PARENT_ERR=!errorlevel!"
    popd
    if "!GIT_PARENT_ERR!"=="0" (
        echo.
        echo [OK] Successfully updated via parent Git repository.
        goto finish
    )
)

REM --- Path 4: Live Cloudflare CDN & Public GitHub Showcase Release ---
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; try { $urls=@('https://wicanfi.pages.dev/WiCanFi-Extension.zip','https://github.com/AabhasKatiyar/wicanfi-platform/releases/latest/download/WiCanFi-Extension.zip','https://github.com/AabhasKatiyar/wicanfi-platform/archive/refs/heads/main.zip'); $ok=$false; foreach($u in $urls){ try { Invoke-WebRequest -Uri $u -OutFile 'wcf_upd.zip' -UseBasicParsing; if((Get-Item 'wcf_upd.zip').Length -gt 1000){ $ok=$true; break } } catch{} }; if(-not $ok){ exit 1 }; Expand-Archive -Path 'wcf_upd.zip' -DestinationPath 'wcf_tmp' -Force; if (Test-Path 'wcf_tmp\manifest.json') { Copy-Item -Path 'wcf_tmp\*' -Destination '.' -Recurse -Force } elseif (Test-Path 'wcf_tmp\WiCanFi-Extension\manifest.json') { Copy-Item -Path 'wcf_tmp\WiCanFi-Extension\*' -Destination '.' -Recurse -Force } elseif (Test-Path 'wcf_tmp\wicanfi-platform-main\extension') { Copy-Item -Path 'wcf_tmp\wicanfi-platform-main\extension\*' -Destination '.' -Recurse -Force; Copy-Item -Path 'wcf_tmp\wicanfi-platform-main\Update-Mac.command' -Destination '.' -Force; Copy-Item -Path 'wcf_tmp\wicanfi-platform-main\version.json' -Destination '.' -Force } else { Copy-Item -Path 'wcf_tmp\*' -Destination '.' -Recurse -Force }; Remove-Item 'wcf_tmp' -Recurse -Force; Remove-Item 'wcf_upd.zip' -Force; exit 0 } catch { exit 1 }"
if not errorlevel 1 (
    echo.
    echo [OK] Successfully updated from WiCanFi live edge network.
    goto finish
)

REM --- Path 5: Git Clone Fallback ---
where git >nul 2>nul
if not errorlevel 1 (
    echo [Info] Fetching latest updates from GitHub showcase repository...
    set "TEMP_DIR=%TEMP%\wcf_upd_%RANDOM%"
    git clone --depth 1 https://github.com/AabhasKatiyar/wicanfi-platform.git "!TEMP_DIR!" >nul 2>&1
    if not errorlevel 1 (
        echo [Info] Applying updated extension files...
        if exist "!TEMP_DIR!\dist\WiCanFi-Extension\manifest.json" (
            xcopy /E /Y /Q "!TEMP_DIR!\dist\WiCanFi-Extension\*" "." >nul
            copy /Y "!TEMP_DIR!\version.json" "." >nul 2>&1
            copy /Y "!TEMP_DIR!\Update-Windows.bat" "." >nul 2>&1
            copy /Y "!TEMP_DIR!\Update-Mac.command" "." >nul 2>&1
            copy /Y "!TEMP_DIR!\How-To-Install.txt" "." >nul 2>&1
        ) else if exist "!TEMP_DIR!\extension\manifest.json" (
            xcopy /E /Y /Q "!TEMP_DIR!\extension\*" "." >nul
            copy /Y "!TEMP_DIR!\Update-Mac.command" "." >nul 2>&1
            copy /Y "!TEMP_DIR!\Update-Windows.bat" "." >nul 2>&1
            copy /Y "!TEMP_DIR!\version.json" "." >nul 2>&1
            copy /Y "!TEMP_DIR!\How-To-Install.txt" "." >nul 2>&1
        )
        rd /s /q "!TEMP_DIR!" >nul 2>&1
        echo.
        echo [OK] Files successfully updated to latest version.
        goto finish
    )
    if exist "!TEMP_DIR!" rd /s /q "!TEMP_DIR!" >nul 2>&1
)
if not errorlevel 1 (
    echo.
    echo [OK] Successfully updated from GitHub release.
    goto finish
)

echo.
echo ================================================================
echo [NOTICE] WiCanFi could not fetch a new update package.
echo.
echo Your internet connection is active and working properly.
echo However, the remote repository is either private or does not yet
echo have a public release package published.
echo ================================================================
echo.
pause
exit /b 1

:finish
:done
echo.
echo [3/3] Finalizing update...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%~dp0' -Recurse -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue" >nul 2>&1
echo.
echo ================================================================
echo  WiCanFi is now up to date!
echo.
echo  Extension folder:
echo  %~dp0
echo ================================================================
echo.

REM --- Step 3: Open the Update Complete page in the user's active/default browser ---
echo [Info] Opening update summary and changelog page in your browser...
set "TARGET_URL=https://wicanfi.pages.dev/update-success"

set "PF86=%ProgramFiles(x86)%"
if not defined PF86 set "PF86=%ProgramFiles%"

set "CHROME_EXE="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "CHROME_EXE=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined CHROME_EXE if exist "%PF86%\Google\Chrome\Application\chrome.exe" set "CHROME_EXE=%PF86%\Google\Chrome\Application\chrome.exe"
if not defined CHROME_EXE if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "CHROME_EXE=%LocalAppData%\Google\Chrome\Application\chrome.exe"

set "EDGE_EXE="
if exist "%PF86%\Microsoft\Edge\Application\msedge.exe" set "EDGE_EXE=%PF86%\Microsoft\Edge\Application\msedge.exe"
if not defined EDGE_EXE if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "EDGE_EXE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

REM Priority 1: Launch directly in Chrome if installed
if defined CHROME_EXE (
    start "" "!CHROME_EXE!" "%TARGET_URL%"
    goto finish_msg
)

REM Priority 2: Launch in Microsoft Edge if installed
if defined EDGE_EXE (
    start "" "!EDGE_EXE!" "%TARGET_URL%"
    goto finish_msg
)

REM Priority 3: Launch via Windows Default Browser handler
start "" "%TARGET_URL%"

:finish_msg
echo.
echo ================================================================
echo  Update complete! The update details page has been opened in
echo  your browser displaying what was fixed and reload steps.
echo ================================================================
echo.
pause
