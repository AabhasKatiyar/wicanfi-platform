#!/bin/bash
# ================================================================
# WiCanFi - Universal macOS 1-Click Installer / Updater
# ================================================================

set -e

echo "================================================================"
echo "          WiCanFi - Apple Mac 1-Click Installer / Updater       "
echo "================================================================"
echo ""

TARGET_DIR="$HOME/Applications/WiCanFi-Extension"
mkdir -p "$TARGET_DIR"

TMP_ZIP="/tmp/WiCanFi-Extension-$$.zip"
TMP_DIR="/tmp/WiCanFi-Extract-$$"

echo "[1/3] Downloading latest WiCanFi Extension package..."
if curl -fsSL -o "$TMP_ZIP" "https://wicanfi.pages.dev/WiCanFi-Extension.zip" 2>/dev/null || \
   curl -fsSL -o "$TMP_ZIP" "https://github.com/AabhasKatiyar/wicanfi/releases/latest/download/WiCanFi-Extension.zip" 2>/dev/null; then
    echo "[OK] Package downloaded successfully."
else
    echo "[ERROR] Failed to download update package. Please check your internet connection."
    exit 1
fi

echo "[2/3] Extracting and unblocking macOS Gatekeeper..."
mkdir -p "$TMP_DIR"
unzip -q -o "$TMP_ZIP" -d "$TMP_DIR"
rm -f "$TMP_ZIP"

if [ -d "$TMP_DIR/WiCanFi-Extension" ]; then
    cp -R "$TMP_DIR/WiCanFi-Extension/"* "$TARGET_DIR/"
else
    cp -R "$TMP_DIR/"* "$TARGET_DIR/"
fi
rm -rf "$TMP_DIR"

# Strip macOS quarantine attributes and grant executable permissions
xattr -cr "$TARGET_DIR" 2>/dev/null || true
chmod -R 755 "$TARGET_DIR"/*.command "$TARGET_DIR"/*.sh 2>/dev/null || true

echo "[3/3] Installation & Update complete!"
echo ""
echo "================================================================"
echo "  WiCanFi Extension installed at: $TARGET_DIR"
echo ""
echo "  To load in Chrome/Brave/Edge:"
echo "  1. Open chrome://extensions"
echo "  2. Enable 'Developer mode'"
echo "  3. Click 'Load unpacked' and select:"
echo "     $TARGET_DIR"
echo "================================================================"
echo ""

open "$TARGET_DIR" 2>/dev/null || true
open "https://wicanfi.pages.dev/update-success.html" 2>/dev/null || true
